1. 'Nop.Plugin.RewardPoint.Sharing' directory contains source code.
2. 'RewardPoint.Sharing' contains binaries. Just drop it into \Plugins directory on your server.