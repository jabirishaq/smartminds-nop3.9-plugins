1. 'Nop.Plugin.Feed.Become' directory contains source code.
2. 'Feed.Become' contains binaries. Just drop it into \Plugins directory on your server.