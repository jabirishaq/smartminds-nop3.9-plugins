1. 'Nop.Plugin.Payments.Cardknox' directory contains source code.
2. 'Payments.Cardknox' contains binaries. Just drop it into \Plugins directory on your server.