1. 'Nop.Plugin.DiscountRules.ShippingCountry' directory contains source code.
2. 'DiscountRules.ShippingCountry' contains binaries. Just drop it into \Plugins directory on your server.