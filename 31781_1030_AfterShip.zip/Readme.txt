1. 'Nop.Plugin.Tracking.AfterShip' directory contains source code.
2. 'Tracking.AfterShip' contains binaries. Just drop it into \Plugins directory on your server.