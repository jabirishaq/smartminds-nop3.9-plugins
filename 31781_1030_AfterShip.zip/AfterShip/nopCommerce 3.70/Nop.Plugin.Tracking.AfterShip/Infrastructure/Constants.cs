﻿namespace Nop.Plugin.Tracking.AfterShip.Infrastructure
{
    public static class Constants
    {
        public const string SHIPMENT_NOTIFICATION_ATTRIBUTE_NAME = "IsSetNotification";
        public const string SHIPMENT_TRACK_NUMBER_ATTRIBUTE_NAME = "TrackNumber";
        public const string SHIPMENT_TRACK_ID_ATTRIBUTE_NAME = "TrackId";
    }
}