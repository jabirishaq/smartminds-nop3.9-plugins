1. 'Nop.Plugin.Widgets.Retargeting' directory contains source code.
2. 'Widgets.Retargeting' contains binaries. Just drop it into \Plugins directory on your server.