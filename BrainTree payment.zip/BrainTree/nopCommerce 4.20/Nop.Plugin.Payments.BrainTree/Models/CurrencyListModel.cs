﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Payments.BrainTree.Models
{
    /// <summary>
    /// Represents a currency list model
    /// </summary>
    public partial class CurrencyListModel : BasePagedListModel<CurrencyModel>
    {
    }
}
