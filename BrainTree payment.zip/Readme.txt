1. 'Nop.Plugin.Payments.BrainTree' directory contains source code.
2. 'Payments.BrainTree' contains binaries. Just drop it into \Plugins directory on your server.