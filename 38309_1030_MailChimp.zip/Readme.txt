1. 'Nop.Plugin.Misc.MailChimp' directory contains source code.
2. 'Misc.MailChimp' contains binaries. Just drop it into \Plugins directory on your server.