1. 'Nop.Plugin.DiscountRules.Store' directory contains source code.
2. 'DiscountRules.Store' contains binaries. Just drop it into \Plugins directory on your server.