Netcash Plugin Directory Structure:
===================================

Please note, the following directory structure applies to each version of the Netcash Payment Plugin:

1. 'Payments.Netcash' contains binaries for the production version of the plugin. Copy the directory into the \Plugins directory of your nopCommerce installation on your server.

2. 'Nop.Plugin.Payments.Netcash' directory contains source code for the plugin.


Contact Netcash at:
===================
Contact: Savashan Naidoo or Byrone Sawyer
Tel: +27 (0)861-338-338
Email: support@netcash.co.za
Website: https://www.netcash.co.za

Contact Teknique Studios at:
============================
Contact: Jaco Ferreira
Tel: +27 (0)44-695-0802
Email: info@tekniquestudios.co.za
Website: https://www.tekniquestudios.co.za