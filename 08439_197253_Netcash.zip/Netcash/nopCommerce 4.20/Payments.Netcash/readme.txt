Netcash PayNow Payment Plug-in
==============================

This plug-in only works with nopCommerce version 4.20.

Setup Instructions - nopCommerce:
=================================

1) Copy/extract the plugin files into your nopCommerce installation on your web server into the following folder:

../Plugins/Payments.Netcash


2) Go to the Administration Panel of your nopCommerce Website and then select "Configuration" > "Plugins" > "Local plugins".

3) Scroll down the list of plugins, look for the Netcash logo and click the Install button next to "Pay Now Gateway".

4) Once installed, click the "Configure" button.

5) Enter your "Merchant Account Number" and "Sage Pay Now Service Key:, and click "Save". This will validate your Netcash credentials.




Setup Instructions - nopCommerce:
=================================

1) Log into your Netcash Account at the following URL:

https://merchant.netcash.co.za/SiteLogin.aspx

2) From the top menu, click on "Account profile"

3) From the left-hand side menu click on Sage connect, and then click on Pay Now

4) Click the "Edit" button at the bottom of the "Pay Now" settings.

5) Enter the following URLs:

Accept URL:   https://www.yourwebsitename.co.za/Plugins/PaymentNetcash/PaymentResultAccept

Decline URL:   https://www.yourwebsitename.co.za/Plugins/PaymentNetcash/PaymentResultDecline

Notify URL:   https://www.yourwebsitename.co.za/Plugins/PaymentNetcash/PaymentResultNotify

Re-direct URL:   https://www.yourwebsitename.co.za/Plugins/PaymentNetcash/PaymentResultRedirect


Please note: You must replace "clientsitename" with your website domain name.

Also ensure that you use "https" if you have an SSL certificate enabled, else it must be "http". SSL is HIGHLY recommended.


Should you experience any problems, then please contact your Netcash Account Manager for assistance.
