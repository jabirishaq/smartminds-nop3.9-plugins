1. 'Nop.Plugin.Payments.TwoCheckout' directory contains source code.
2. 'Payments.TwoCheckout' contains binaries. Just drop it into \Plugins directory on your server.