﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Payments.TwoCheckout.Models
{
    public class IpnModel : BaseNopModel
    {
    }
}
